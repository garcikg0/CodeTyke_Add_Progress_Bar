### CodeTyke 

This is a repo to accompany the BrightCode course "Programming in an Enterprise Environment". 

If you have any questions, feel free to contact your instructor or  
[email us](mailto:info@brightcode.dev?subject=[CodeTyke]).